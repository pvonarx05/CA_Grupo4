#!/bin/bash
#
# backup_full.sh - Script de backup para TPServer
# Universidad de Palermo - TP Integrador
#
# Uso: ./backup_full.sh <origen> <destino>
#

# --------- Función de ayuda ---------
mostrar_ayuda() {
    echo "==============================================="
    echo "  backup_full.sh - Script de backup completo"
    echo "==============================================="
    echo ""
    echo "Uso:"
    echo "  $0 <origen> <destino>"
    echo "  $0 -help"
    echo ""
    echo "Parametros:"
    echo "  <origen>   Directorio a respaldar (ej: /var/log)"
    echo "  <destino>  Directorio donde se guarda el backup (ej: /backup_dir)"
    echo ""
    echo "Opciones:"
    echo "  -help      Muestra esta ayuda"
    echo ""
    echo "Ejemplos:"
    echo "  $0 /var/log /backup_dir"
    echo "  $0 /www_dir /backup_dir"
    echo ""
    echo "El backup se guarda como:"
    echo "  <nombre_origen>_bkp_YYYYMMDD.tar.gz"
    echo ""
    exit 0
}

# --------- Procesar argumento -help ---------
if [ "$1" = "-help" ] || [ "$1" = "--help" ] || [ "$1" = "-h" ]; then
    mostrar_ayuda
fi

# --------- Validar cantidad de argumentos ---------
if [ $# -ne 2 ]; then
    echo "ERROR: Cantidad de argumentos incorrecta."
    echo "Use '$0 -help' para ver la ayuda."
    exit 1
fi

ORIGEN="$1"
DESTINO="$2"

# --------- Validar que el origen existe ---------
if [ ! -d "$ORIGEN" ]; then
    echo "ERROR: El directorio de origen '$ORIGEN' no existe o no es accesible."
    exit 2
fi

# --------- Validar que el destino existe ---------
if [ ! -d "$DESTINO" ]; then
    echo "ERROR: El directorio de destino '$DESTINO' no existe o no es accesible."
    exit 3
fi

# --------- Validar que el destino sea escribible ---------
if [ ! -w "$DESTINO" ]; then
    echo "ERROR: El directorio de destino '$DESTINO' no es escribible."
    exit 4
fi

# --------- Armar nombre del archivo ---------
NOMBRE_BASE=$(basename "$ORIGEN")
FECHA=$(date +%Y%m%d)
ARCHIVO="${NOMBRE_BASE}_bkp_${FECHA}.tar.gz"
RUTA_DESTINO="${DESTINO}/${ARCHIVO}"

# --------- Ejecutar backup ---------
echo "==============================================="
echo "  Iniciando backup..."
echo "  Origen:  $ORIGEN"
echo "  Destino: $RUTA_DESTINO"
echo "  Fecha:   $(date)"
echo "==============================================="

tar -czf "$RUTA_DESTINO" -C "$(dirname "$ORIGEN")" "$NOMBRE_BASE" 2>/dev/null

# --------- Verificar exito ---------
if [ $? -eq 0 ]; then
    TAMANO=$(du -h "$RUTA_DESTINO" | cut -f1)
    echo "  Backup completado exitosamente."
    echo "  Tamano: $TAMANO"
    exit 0
else
    echo "  ERROR durante el backup."
    exit 5
fi
