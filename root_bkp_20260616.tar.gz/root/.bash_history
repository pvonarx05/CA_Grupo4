history
history -w
rm -f /root/.bash_history
journalctl --rotate
journalctl --vacuum-time=1s
apt clean
sync
poweroff
hostnamectl set-hostname TPServer
vi /etc/hosts
hostname
hostnamectl status
ping -c 2 TPServer
cat /etc/debian_version
apt update
poweroff
ip a
ping -c 4 8.8.8.8
ping -c 4 google.com
nano /etc/resolv.conf
vi /etc/resolv.conf
ping -c 4 google.com
echo "precedence ::ffff:0:0/96 100" >> /etc/gai.conf
ping -c 4 google.com
apt update
apt upgrade -y
vi /etc/apt/sources.list
apt update
apt upgrade -y
echo "acquire::ForceIPv4 "true"; > /etc/apt/apt.conf.d/99force-ipv4
echo"Acquire::retries "5";" >> /etc/apt/apt.conf.d/99force-ipv4
apt clean
apt clean
apt upgrade -y --fix-missing
apt update
apt --fix-broken install -y
apt upgrade -y --fix-missing
apt upgrade -y --fix-missing
apt -y --fix-missing
apt upgrade -y --fix-missing
apt upgrade
cat /etc/debian_version
vi /etc/apt/sources.list


apt full-upgrade -y
apt --fix-broken install -y
poweroff
apt update
apt full-upgrade -y --fix-missing
vi /etc/apt(sources.list
vi /etc/apt/sources.list
apt clean
rm -rf /var/lib/apt/lists/*
apt update
root@TPServer:~#
poweroff
dpkg --configure -a
apt --fix-broken install -y
apt update
shutdown -h now
ip a
ip a
ping -c 4 deb.debian.org
apt clean
rm -rf /var/lib/apt/lists/*
apt update
apt upgrade -y
apt autoremove -y
reboot
uname -r
apt update
apt autoremove -y
apt clean
apt list --upgradable
dmesg | grep -i "soft\|watch\|error"
journalctl -p 3 -xb
free -h
top
free -h
watchdog: BUG: soft lockup
journalctl -p 3 -xb
poweoff
poweroff
dmesg | grep -i vmwgfx
cat /etc/debian_version
cat /etc/os-release
PRETTY_NAME="Debian GNU/Linux 12"
cat /etc/os-release
apt install openssh-server -y
systemctl status ssh
ssh-keygen -t rsa -b 4096
mkdir -p /root/.ssh
cat /root/.ssh/id_rsa.pub
chmod 700 /root/.ssh
chmod 600 /root/.ssh/authorized_keys
cat /root/.ssh/id_rsa.pub >> /root/.ssh/authorized_keys
chmod 700 /root/.ssh
chmod 600 /root/.ssh/authorized_keys
nano /etc/ssh/sshd_config
apt install nano -y
nano/etc/ssh/sshd_config
nano /etc/ssh/sshd_config
systemctl restart ssh
systemctl status ssh
apt install apache2 php libapache2-mod-php mariadb-server -y
systemctl status apache 2
systemctl status apache2
systemctl status mariadb
php -v
cp /root/index.php /var/www/html/
ls -la /root
tar -xzvf /root/Material_Adicional_TPVMCA.tar.gz
cp/root/Material_Adicional_TPVMCA/index.php /var/www/html/
cp /root/Material_Adicional_TPVMCA/index.php /var/www/html/
cp /root/Material_Adicional_TPVMCA/logo.png /var/www/html/
ls -lah /var/www/html
rm /var/www/html/index.html
systemctl restar apache2
systemctl restart apache2
ls -lah /var/www/html
mysql -u root
mysql -u root tpvmca < /root/Material_Adicional_TPVMCA/db.sql
mysql -u root
head -30 /root/Material_Adicional_TPVMCA/db.sql
cat /root/Material_Adicional_TPVMCA/db.sql
mysql -u root
cat /root/Material_Adicional_TPVMCA/db.sql
cp /root/Material_Adicional_TPVMCA/clave_publica.pub /root/.ssh/authorized_keys
chmod 700 /root/.ssh
chmod 600 /root/.ssh/authorized_keys
ls -lah /root/.ssh
cp /root/Material_Adicional_TPVMCA/clase_privada.txt /root/.ssh/id_rsa
cp /root/Material_Adicional_TPVMCA/clave_publica.pub /root/.ssh/authorized_keys
cp /root/Material_Adicional_TPVMCA/clave_publica.pub /root/.ssh/authorized_keys
cp /root/Material_Adicional_TPVMCA/clave_privada.txt /root/.ssh/is_rsa
cp /root/Material_Adicional_TPVMCA/clave_publica.pub /root/.ssh/is_rsa.pub
chmod 600 /root/.ssh/id_rsa
chmod 600 /root/.ssh/id_rsa.pub
chmod 600 /root/.ssh/authorized_keys
ls -lah /root/.ssh
rm /root/.ssh/id_rsa
rm /root/.ssh/id_rsa.pub
mv /root/.ssh/is:rsa /root/.ssh/id_rsa
mv /root/.ssh/is_rsa /root/.ssh/id_rsa
mv /root/.ssh/is_rsa.pub /root/.ssh/id_rsa.pub
chmod 600 /root/.ssh/id_rsa
chmod 600 /root/.ssh/id_rsa.pub
chmod 600 /root/.ssh/authorized_keys
ls -lah /root/.ssh
grep PermitRoot /etc/ssh/sshd_config
grep PubkeyAuthentication etc/ssh/sshd_config
grep PermitRootLogin /etc/ssh/sshd_config
grep PubkeyAuthentication /etc/ssh/sshd_config
echo "PermitRootLogin yes" \
echo "PermitRootLogin yes" >> /etc/ssh/sshd_config
echo "PubkeyAuthentication yes" >> /etc/ssh/sshd_config
tail -5 /etc/ssh/sshd_config
systemctl restart ssh
systemctl status ssh
ls -lah /root/Material_Adicional_TPVMCA
cp /root/Material_Adicional_TPVMCA/clave_privada.txt /root/.ssh/id_rsa
cp /root/Material_Adicional_TPVMCA/clave_publica.pub /root/.ssh/id_rsa.pub
chmod 600 /root/.ssh/id_rsa
chmod 644 /root/.ssh/id_rsa.pub
chmod 600 /root/.ssh/authorized_keys
ls -lah /root/.ssh
shutdown -h now
shutdown -h now
clear
ip a
clear
ip route
clear
ip a
clear
ip route
clear
vim /etc/network/interfaces
clear
/etc/initd.d/networking restart
ifup enp0s3
ping 8.8.8.8
clear
shutdown -r now
clear
ping 8.8.8.8
vim /etc/network/interfaces
ifup enp0s3
vim /etc/network/interfaces
ifup enp0s3
/etc/initd.d/networking restart
ifup enp0s3
clear
ifup enp0s3
vim /etc/network/interfaces
ifup enp0s3
clear
ping 8.8.8.8
clear
shutdown -r now
clear
ping 8.8.8.8
clear
ping 192.168.1.82
clear
ping 192.168.1.1
clear
ping 8.8.8.8
clear
ping 192.168.1.42
clear
ip addr
clear
ip route
ping 192.168.1.42
clear
ping 192.168.1.42
clear
ping 192.168.1.42
clear
vim /etc/ssh/sshd_config
clear
ip a
clear
vim /etc/network/interfaces
clear
shutdown -h now
clear
systemctl restart ssh
clear
systemctl status ssh
clear
whoami
clear
ls -lh
poweroff
fdisk
lsblk
poweroff
fdisk /dev/sdc
n
poweroff
lsblk
poweroff
lsblk
fdisk /dev/sdd
mkfs.ext4 /dev/sdd1
mkfs.ext4 /dev/sdd2
mkdir -p /www_dir
mkdir -p /backup_dir
nano /etc/fstab
mount -a
cp /root/index.php /www.dir/
systemctl daemon-reload
find / -name "index.php" 2>/dev/null
cp /var/www/html/index.php /www_dir/
cp /var/www/html/logo.png /www_dir/
chown -R www-data:www-data /www_dir
chmod -R 755 /www_dir
nano /etc/apache2/sites-available/000-default.conf
nano /etc/apache2/apache2.conf
systemctl restart apache2
apache2ctl configtest
nano /etc/apache2/apache2.conf
apache2ctl configtest
systectl restart apache2
systemctl restart apache2
cat /proc/partitions > /opt/particion
df -h
poweroff
clear
su - root
hostname
clear
cat /etc/hosts | grep TPServer
clear
lsb_release -a
uname -r
clear
systemctl status ssh
ls -la /root/.ssh/
clear
hostname
clear
hostname
lsb_release -a
cat /etc/debian_version
systemctl status ssh
grep PermitRootLogin /etc/ssh/sshd_config
cat  /etc/ssh/sshd_config
clear
cat /etc/network/interfaces
cat /etc/ssh/sshd_config
nano /etc/ssh/sshd_config
nano /etc/ssh/sshd_config
ls -lah /root/.ssh
cat /root/.ssh/authorized_keys
clear
systemctl status apache2
clear
php -v
apachectl -S
grep DocumentRoot /etc/apache2/sites-enabled/000-default.conf
clear
apachectl -S
grep DocumentRoot /etc/apache2/sites-enabled/000-default.conf
ls -lah /www_dir
curl http://192.168.1.88
systemctl status apache2
curl http://192.168.1.88
http://192.168.1.88
curl http://192.168.1.88
systemctl status mariadb
clear
systemctl status mariadb
clear
mysql -u root
clear
cat /etc/network/interfaces
ip a
ip route
fdisk -l
clear
fdisk -l
clear
lsblk
df -h
cat /etc/fstab
mount -a
clear
ls -lah /opt/particion
cat /opt/particion
clear
ls -lah /opt/particion
cat /opt/particion
cat /proc/partitions
/opt/scripts/backup_full.sh -help
/opt/scripts/backup_full.sh /var/log /backup_dir
ls -lah /backup_dir
crontab -l
systemctl status cron
clear

cat /root/Material_Adicional_TPVMCA/db.sql 
clear
mysql -u root
mysql -u root tpvmca < /root/Material_Adicional_TPVMCA/db.sql 
nano /root/Material_Adicional_TPVMCA/db.sql 
mysql -u root tpvmca < /root/Material_Adicional_TPVMCA/db.sql 
nano /root/Material_Adicional_TPVMCA/db.sql 
nano /root/Material_Adicional_TPVMCA/db.sql 
mysql -u root tpvmca < /root/Material_Adicional_TPVMCA/db.sql 
nano /root/Material_Adicional_TPVMCA/db.sql 
mysql -u root tpvmca < /root/Material_Adicional_TPVMCA/db.sql 
mysql -u root
nano /root/Material_Adicional_TPVMCA/db.sql 
mysql -u root
nano /root/Material_Adicional_TPVMCA/db.sql 
mysql -u root
clear
curl 192.168.1.1
clear
